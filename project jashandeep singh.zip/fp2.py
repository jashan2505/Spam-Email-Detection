# Data handling
import pandas as pd
import numpy as np

# Text preprocessing
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

#Feature extraction
from sklearn.feature_extraction.text import TfidfVectorizer

# ML models and utilities
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# File handling
import joblib
import os

# Load dataset
dataset_path = r"C:\Users\Acer\Downloads\spam_ham_dataset.csv"
if not os.path.exists(dataset_path):
    print(f"Dataset not found at: {dataset_path}")
    print("Please check the file path and ensure the dataset exists.")
    exit()

df = pd.read_csv(dataset_path)
print("Dataset loaded successfully!")
print(df.head())
print(df.columns)
print(df.info())
print(df.isnull().sum())

#Class distribution
print(df['label'].value_counts())
print(df['label'].value_counts(normalize=True))

# Duplicates
print(f"Duplicates: {df.duplicated().sum()}")

# Text length analysis
df['text_length'] = df['text'].str.len()
print(df.groupby('label')['text_length'].describe())

# Text preprocessing
nltk.download('stopwords')
ps = PorterStemmer()
stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    text = text.lower()
    text = ''.join([c for c in text if c not in string.punctuation])
    tokens = text.split()
    tokens = [ps.stem(word) for word in tokens if word not in stop_words]
    return ' '.join(tokens)

df['processed_text'] = df['text'].apply(preprocess_text)

# TF-IDF vectorization
vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
X = vectorizer.fit_transform(df['processed_text'])
# Convert 'ham' and 'spam' labels to 0 and 1
df['label'] = df['label'].map({'ham': 0, 'spam': 1})
y = df['label']


#  Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

# =============================
#Model 1: Naive Bayes
# =============================
nb_model = MultinomialNB()
nb_model.fit(X_train, y_train)
nb_pred = nb_model.predict(X_test)

print("\n Naive Bayes Results:")
print(f"Accuracy: {accuracy_score(y_test, nb_pred):.4f}")
print(classification_report(y_test, nb_pred))

# =============================
# Model 2: Logistic Regression
# =============================
lr_model = LogisticRegression(max_iter=1000)
lr_model.fit(X_train, y_train)
lr_pred = lr_model.predict(X_test)

print("\n Logistic Regression Results:")
print(f"Accuracy: {accuracy_score(y_test, lr_pred):.4f}")
print(classification_report(y_test, lr_pred))

# =============================
#  Model 3: Support Vector Machine (SVM)
# =============================
svm_model = SVC(kernel='linear')
svm_model.fit(X_train, y_train)
svm_pred = svm_model.predict(X_test)

print("\n SVM Results:")
print(f"Accuracy: {accuracy_score(y_test, svm_pred):.4f}")
print(classification_report(y_test, svm_pred))

# =============================
# Confusion Matrices
# =============================
models = {
    "Naive Bayes": nb_pred,
    "Logistic Regression": lr_pred,
    "SVM": svm_pred
}

plt.figure(figsize=(15, 4))
for i, (name, pred) in enumerate(models.items(), 1):
    cm = confusion_matrix(y_test, pred)
    plt.subplot(1, 3, i)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Ham', 'Spam'], yticklabels=['Ham', 'Spam'])
    plt.title(f"{name} Confusion Matrix")
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
plt.tight_layout()
plt.show()

# ===========================================
# Final Model Comparison Summary
# ===========================================

# Store metrics in a dictionary
model_results = {
    "Naive Bayes": accuracy_score(y_test, nb_pred),
    "Logistic Regression": accuracy_score(y_test, lr_pred),
    "SVM": accuracy_score(y_test, svm_pred)
}

# Display as DataFrame
results_df = pd.DataFrame.from_dict(model_results, orient='index', columns=['Accuracy'])
results_df = results_df.sort_values(by='Accuracy', ascending=False)
print("\n Model Accuracy Comparison:\n")
print(results_df)

# Plot accuracy comparison
plt.figure(figsize=(8, 5))
sns.barplot(x=results_df.index, y='Accuracy',hue=results_df.index, data=results_df, palette='viridis')
plt.ylim(0.8, 1.0)
plt.title("Model Accuracy Comparison")
plt.ylabel("Accuracy")
plt.xlabel("Model")
plt.tight_layout()
plt.show()

# =============================
# Save Models
# =============================
print("\n" + "="*50)
print("SAVING MODELS")
print("="*50)

try:
    # Save models in the current directory
    joblib.dump(svm_model, "svm_model.pkl")
    joblib.dump(vectorizer, "tfidf_vectorizer.pkl")
    
    print("✅ Models saved successfully!")
    print(f"✅ svm_model.pkl saved in: {os.path.abspath('svm_model.pkl')}")
    print(f"✅ tfidf_vectorizer.pkl saved in: {os.path.abspath('tfidf_vectorizer.pkl')}")
    
    # Verify files were created
    if os.path.exists("svm_model.pkl"):
        print("✅ svm_model.pkl file verified")
    else:
        print("❌ svm_model.pkl file not found after saving")
        
    if os.path.exists("tfidf_vectorizer.pkl"):
        print("✅ tfidf_vectorizer.pkl file verified")
    else:
        print("❌ tfidf_vectorizer.pkl file not found after saving")
        
except Exception as e:
    print(f"❌ Error saving models: {str(e)}")

print("\n" + "="*50)
print("TRAINING COMPLETE")
print("="*50)
import streamlit as st
import joblib
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import os

# Download stopwords (only once)
nltk.download('stopwords', quiet=True)

# Function to load models with error handling
@st.cache_resource
def load_models():
    """Load the trained model and vectorizer with proper error handling"""
    try:
        # Try to load from current directory first
        model_path = "svm_model.pkl"
        vectorizer_path = "tfidf_vectorizer.pkl"
        
        if not os.path.exists(model_path):
            st.error(f"Model file '{model_path}' not found in current directory!")
            st.info("Please ensure the model files are in the same directory as this app.")
            return None, None
            
        if not os.path.exists(vectorizer_path):
            st.error(f"Vectorizer file '{vectorizer_path}' not found in current directory!")
            st.info("Please ensure the vectorizer files are in the same directory as this app.")
            return None, None
            
        model = joblib.load(model_path)
        vectorizer = joblib.load(vectorizer_path)
        
        return model, vectorizer
        
    except Exception as e:
        st.error(f"Error loading models: {str(e)}")
        return None, None

# Load model and vectorizer
model, vectorizer = load_models()

# Preprocessing function
ps = PorterStemmer()
stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    """Preprocess text for prediction"""
    text = text.lower()
    text = ''.join([c for c in text if c not in string.punctuation])
    tokens = text.split()
    tokens = [ps.stem(word) for word in tokens if word not in stop_words]
    return ' '.join(tokens)

# Streamlit UI
st.title("📧 Spam Email Classifier")
st.markdown("Enter the email content below and classify it as **Spam** or **Ham**.")

# Check if models are loaded successfully
if model is None or vectorizer is None:
    st.warning("⚠️ Models not loaded. Please check the error messages above.")
    st.markdown("### Steps to fix:")
    st.markdown("1. Make sure `svm_model.pkl` and `tfidf_vectorizer.pkl` are in the same directory as this app")
    st.markdown("2. Run the training script to generate the model files")
    st.markdown("3. Restart the Streamlit app")
else:
    st.success("✅ Models loaded successfully!")
    
    input_text = st.text_area("✉️ Email Content", height=200)

    if st.button("🔍 Predict"):
        if input_text.strip() == "":
            st.warning("Please enter some text!")
        else:
            try:
                cleaned = preprocess_text(input_text)
                vector_input = vectorizer.transform([cleaned])
                prediction = model.predict(vector_input)[0]

                if prediction == 1:
                    st.error("🚫 This is **SPAM**!")
                else:
                    st.success("✅ This is **HAM** (not spam).")
                    
            except Exception as e:
                st.error(f"Error during prediction: {str(e)}")

# Display file information
st.sidebar.header("📁 File Information")
if os.path.exists("svm_model.pkl"):
    st.sidebar.success("✅ svm_model.pkl found")
else:
    st.sidebar.error("❌ svm_model.pkl missing")
    
if os.path.exists("tfidf_vectorizer.pkl"):
    st.sidebar.success("✅ tfidf_vectorizer.pkl found")
else:
    st.sidebar.error("❌ tfidf_vectorizer.pkl missing")

